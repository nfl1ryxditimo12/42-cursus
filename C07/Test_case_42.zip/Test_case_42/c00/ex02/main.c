/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shpark <shpark@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/28 05:29:37 by shpark            #+#    #+#             */
/*   Updated: 2020/01/30 08:39:49 by shpark           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_print_reverse_alphabet.c"

int		main(void)
{
	ft_print_reverse_alphabet();
	printf("\n");
	printf("Correct Answer : zyxwwvutsrqponmlkjihgfedcba\n");
}
