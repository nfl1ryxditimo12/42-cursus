# Test_case_42
=================

- shpark by 42 Seoul 1th

- 42 서울 1기 shpark(박신철)
 
- Use this example to test your 42 C Piscine subjects or review your peer's codes.

- 42 C 피신 (라 피신) 과제를 테스트하거나, 동료의 코드를 리뷰하는데 이 테스트 케이스를 사용하세요.

- If you want to add any other test case, contact me by the slack or the 42 intra or the offline.

- 추가할 테스트 케이스가 있으면 slack 또는 42 intra 또는 오프라인으로 연락바랍니다.

# How to use

1. ``` git clone https://github.com/michaelparkerr/Test_case_42``` in directory you want test

2. ```cd Test_case_42```

3. ```cd cxx```(what you test)

4. Excute ```./test.sh```

# 사용 방법

1. ``` git clone https://github.com/michaelparkerr/Test_case_42``` 명령어를 테스트할 디렉토리 안에서 입력합니다.(ex..이 있는 폴더 안)

2. ```cd Test_case_42```

3. ```cd cxx```(테스트할 과제의 번호를 가진 폴더로 이동)

4. ```./test.sh```

## Don't change Folder's, File's Name. Just Use IT

## 폴더명, 파일명 바꾸지 마세요. 그냥 사용하세요
